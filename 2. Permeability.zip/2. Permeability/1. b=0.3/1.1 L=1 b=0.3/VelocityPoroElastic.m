function [ NCv11,NCv12,NCv21,NCv22,av11new1,av12new1,av21new1,av22new1,av22new2,av12new2,av12new3,av22new3,av21new2,av11new2,av21new3,av11new3]=VelocityPoroElastic(j1up,j1down,j2up,j2down,j3up,j3down,nx,NCv11,NCv12,NCv21,NCv22,NCsigma_xy,NCsigma_xx,NCsigma_yy,NCp,Coeff_21,Coeff_22,Coeff_23,Coeff_24,Coeff_25,Coeff_26,Coeff_27,Coeff_28,FourthOrder,tt,av11new1,av12new1,av21new1,av22new1,av12new2,av12new3,av22new2,av22new3,av21new2,av11new2,av21new3,av11new3)
%----------------------------------------------------------------------------------------------------------------------------------------------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
j=j1up:1:j1down ;  % v12 is zero at bottom %BOTTOM RIGID        
i=1:(-1+nx):nx; 

DNCsigma_xy1 = NCsigma_xy(i+1,j+1)- NCsigma_xy(i,j+1);  
DNCp1 = NCp(i,j+1)-NCp(i,j);
DNCsigma_yy = NCsigma_yy(i,j+1)-NCsigma_yy(i,j);

switch(tt)
    
    case 1
     a=2;
     b=-j1up+j1down+1;
        av12new1=zeros(a,b);
end

       av12old1 = av12new1;

               av12new1=( Coeff_21 * (DNCsigma_xy1 ) + Coeff_22 * ( DNCsigma_yy ) + Coeff_23 * ( DNCp1 )  + Coeff_24 * NCv22(i,j) );
               
               NCv12(i,j) = NCv12(i,j) +  3/2 * av12new1 - 1/2 * av12old1 ;
                

j=j1up:(-j1up+j1down):j1down ;
i=2:1:(nx-1)  ; 

DNCsigma_xy1 = NCsigma_xy(i+1,j+1)- NCsigma_xy(i,j+1);
DNCsigma_yy = NCsigma_yy(i,j+1)-NCsigma_yy(i,j);
DNCp1 = NCp(i,j+1)-NCp(i,j);

switch(tt)
      
    case 1
        
    a=nx-2;
    b=2;
         av12new2=zeros(a,b);

end
         av12old2 = av12new2;
       
              av12new2=( Coeff_21 * (DNCsigma_xy1) + Coeff_22 * ( DNCsigma_yy ) + Coeff_23 * ( DNCp1 )  + Coeff_24 * NCv22(i,j)   );
              
              NCv12(i,j) = NCv12(i,j) +  3/2 * av12new2 - 1/2 * av12old2 ;           
                                                                 
% %444444444 order

j=(j1up+1):1:(j1down-1) ;
i=2:1:nx-1  ; 

switch(FourthOrder)
    
    case 1
        
DNCsigma_xy1 = ( 27*(NCsigma_xy(i+1,j+1)- NCsigma_xy(i,j+1))- ( NCsigma_xy(i+2,j+1)- NCsigma_xy(i-1,j+1) ) )/24;

DNCsigma_yy = ( 27*(NCsigma_yy(i,j+1)-NCsigma_yy(i,j)) - (NCsigma_yy(i,j+2)-NCsigma_yy(i,j-1)) )/24;

DNCp1 = ( 27*(NCp(i,j+1)-NCp(i,j) )-( NCp(i,j+2)-NCp(i,j-1) ) )/24;

    case 0
        
DNCsigma_xy1 = NCsigma_xy(i+1,j+1)- NCsigma_xy(i,j+1);

DNCsigma_yy = NCsigma_yy(i,j+1)-NCsigma_yy(i,j);

DNCp1 = NCp(i,j+1)-NCp(i,j);

end

switch(tt)
      
    case 1
        
     a=nx-2;
     
     b=-(j1up+1)+(j1down-1)+1;
     
         av12new3=zeros(a,b);

end
         av12old3 = av12new3;
       
              av12new3=( Coeff_21 * (DNCsigma_xy1) + Coeff_22 * ( DNCsigma_yy ) + Coeff_23 * ( DNCp1 )  + Coeff_24 * NCv22(i,j)  );
              
              NCv12(i,j) = NCv12(i,j) +  3/2 * av12new3 - 1/2 * av12old3 ;           
%                
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
              
    %GO THROGUH                                                                                                         
                           
j=j2up:1:j2down ;  % v12 is zero at bottom %BOTTOM RIGID

i=1:(-1+nx):nx; 

switch(tt)
    
    case 1
        
    a=1;
    
    b=-j2up+j2down+1;
    
        av22new1=zeros(a,b);
        
end
        av22old1 = av22new1;
        
DNCp1 = NCp(i,j+1)-NCp(i,j);
DNCsigma_xy1 = NCsigma_xy(i+1,j+1)- NCsigma_xy(i,j+1);
DNCsigma_yy = NCsigma_yy(i,j+1)-NCsigma_yy(i,j);

              av22new1=(  Coeff_25 * ( DNCp1 ) + Coeff_26 * NCv22(i,j) + Coeff_27 * ( DNCsigma_xy1 ) +  Coeff_23* ( DNCsigma_yy )  );
              NCv22(i,j) = NCv22(i,j) - 3/2 * av22new1 + 1/2 * av22old1 ;

          
i=2:1:(nx-1)  ; 
j=j2up:j2down-j2up:j2down ;
switch(tt)
      
    case 1
     a=nx-2;
     b=2;
         av22new2=zeros(a,b);

end
         av22old2 = av22new2;

DNCp1 = NCp(i,j+1)-NCp(i,j);
DNCsigma_xy1 = NCsigma_xy(i+1,j+1)- NCsigma_xy(i,j+1);
DNCsigma_yy = NCsigma_yy(i,j+1)-NCsigma_yy(i,j);

             av22new2=(  Coeff_25 * ( DNCp1 ) + Coeff_26 * NCv22(i,j) + Coeff_27 * ( DNCsigma_xy1 ) +  Coeff_23* ( DNCsigma_yy )  );          
             NCv22(i,j) = NCv22(i,j) - 3/2 * av22new2 + 1/2 * av22old2;                
             
 %44444444444444444th order      
 
i=2:1:nx-1  ; 

j=j2up+1:1:j2down-1 ;

switch(tt)
      
    case 1
        
    a=nx-2;
    
    b=-(j2up+1)+(j2down-1)+1;
    
         av22new3=zeros(a,b); 

end
         av22old3 = av22new3;

 switch(FourthOrder)
     
    case 1        
        
DNCp1 =( 27*( NCp(i,j+1)-NCp(i,j) ) -(NCp(i,j+2)-NCp(i,j-1)) )/24;

DNCsigma_xy1 = ( 27 * ( NCsigma_xy(i+1,j+1)- NCsigma_xy(i,j+1) ) - ( NCsigma_xy(i+2,j+1)- NCsigma_xy(i-1,j+1) ) )/24;

DNCsigma_yy = ( 27* ( NCsigma_yy(i,j+1)-NCsigma_yy(i,j) ) - ( NCsigma_yy(i,j+2)-NCsigma_yy(i,j-1) ) ) /24 ;

     case 0
         
DNCp1 = NCp(i,j+1)-NCp(i,j);

DNCsigma_xy1 = NCsigma_xy(i+1,j+1)- NCsigma_xy(i,j+1);

DNCsigma_yy = NCsigma_yy(i,j+1)-NCsigma_yy(i,j);

 end

           av22new3=(  Coeff_25 * ( DNCp1 ) + Coeff_26 * NCv22(i,j) + Coeff_27 * ( DNCsigma_xy1 ) +  Coeff_23* ( DNCsigma_yy ) );          
             NCv22(i,j) = NCv22(i,j) - 3/2 * av22new3 + 1/2 * av22old3;                       
             
             
             
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
             
j=j3up:1:j3down ;   %BOTTOM RIGID !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!        
i=2:(nx-2):nx   ;    % v11 and v21 are zero at both sides    

DNCp2 = NCp(i,j)-NCp(i-1,j);
DNCsigma_xy2 = NCsigma_xy(i,j+1) - NCsigma_xy(i,j);
DNCsigma_xx = NCsigma_xx(i,j)-NCsigma_xx(i-1,j);


switch(tt)
      
    case 1
        
    a=2;
    b=-j3up+j3down+1;
    
         av21new1=zeros(a,b);
         av11new1=zeros(a,b);
end
         av21old1 = av21new1;
         av11old1 = av11new1;
          
            av21new1=( Coeff_28  * ( DNCp2 ) +Coeff_26  * NCv21(i,j)+Coeff_27 * ( DNCsigma_xx ) +Coeff_23 *( DNCsigma_xy2 )  );
            av11new1=( Coeff_21 * ( DNCsigma_xx ) + Coeff_22 *( DNCsigma_xy2 ) + Coeff_27 * ( DNCp2 ) + Coeff_24 * NCv21(i,j)  );

             NCv21(i,j) = NCv21(i,j) - 3/2 * av21new1 + 1/2 * av21old1;
             NCv11(i,j) = NCv11(i,j) + 3/2 * av11new1 - 1/2 * av11old1;
             
              
             
 j=j3up:(-j3up+j3down):j3down ;   %BOTTOM RIGID !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!        
 i=3:1:(nx-1)   ;    % v11 and v21 are zero at both sides    

DNCp2 = NCp(i,j)-NCp(i-1,j);
DNCsigma_xy2 = NCsigma_xy(i,j+1) - NCsigma_xy(i,j);
DNCsigma_xx = NCsigma_xx(i,j)-NCsigma_xx(i-1,j);


switch(tt)
      
    case 1
    a=nx-3;
    b=2;
         av21new2=zeros(a,b);
         av11new2=zeros(a,b);
end
         av21old2 = av21new2;
         av11old2 = av11new2;
          
            av21new2=(  Coeff_28  * ( DNCp2 ) +Coeff_26  * NCv21(i,j)+Coeff_27 * ( DNCsigma_xx ) +Coeff_23 *( DNCsigma_xy2 ) );
            av11new2=(  Coeff_21 * ( DNCsigma_xx ) + Coeff_22 *( DNCsigma_xy2 ) + Coeff_27 * ( DNCp2 ) + Coeff_24 * NCv21(i,j) );

             NCv21(i,j)=NCv21(i,j) - 3/2 * av21new2 + 1/2 * av21old2;
             NCv11(i,j)=NCv11(i,j) + 3/2 * av11new2 - 1/2 * av11old2;            
             
                                     
% 4444444444444444444th order

j=(j3up+1):1:(j3down-1) ;   %BOTTOM RIGID !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!        
i=3:1:(nx-1);    % v11 and v21 are zero at both sides    


 switch(FourthOrder)
    case 1 
DNCp2 = ( 27*( NCp(i,j)-NCp(i-1,j)) - (NCp(i,j)-NCp(i-1,j)) )/24;
DNCsigma_xy2 =  ( 27* ( NCsigma_xy(i,j+1) - NCsigma_xy(i,j) )- ( NCsigma_xy(i,j+2) - NCsigma_xy(i,j-1) )) /24 ;
DNCsigma_xx = ( 27* ( NCsigma_xx(i,j)-NCsigma_xx(i-1,j) ) - ( NCsigma_xx(i+1,j)-NCsigma_xx(i-2,j) ) )/24;
     case 0
DNCp2 = NCp(i,j)-NCp(i-1,j);
DNCsigma_xy2 = NCsigma_xy(i,j+1) - NCsigma_xy(i,j);
DNCsigma_xx = NCsigma_xx(i,j)-NCsigma_xx(i-1,j);
 end
 
switch(tt)
      
    case 1
        
    a=nx-3;
    b=-(j3up+1)+(j3down-1)+1;
    
         av21new3=zeros(a,b);
         av11new3=zeros(a,b);
end
         av21old3 = av21new3;
         av11old3 = av11new3;
          
            av21new3=(  Coeff_28  * ( DNCp2 ) +Coeff_26  * NCv21(i,j)+Coeff_27 * ( DNCsigma_xx ) +Coeff_23 *( DNCsigma_xy2 )  );
            av11new3=(  Coeff_21 * ( DNCsigma_xx ) + Coeff_22 *( DNCsigma_xy2 ) + Coeff_27 * ( DNCp2 ) + Coeff_24 * NCv21(i,j) );

             NCv21(i,j)=NCv21(i,j) - 3/2 * av21new3 + 1/2 * av21old3;
             NCv11(i,j)=NCv11(i,j) + 3/2 * av11new3 - 1/2 * av11old3;



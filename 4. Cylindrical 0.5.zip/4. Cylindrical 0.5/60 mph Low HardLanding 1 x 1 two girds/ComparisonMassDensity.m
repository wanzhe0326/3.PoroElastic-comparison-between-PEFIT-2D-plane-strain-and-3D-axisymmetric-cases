
point=1;
x=linspace(1,800,800);


% for ii=1:1:400
% y2(1,ii)=result1(ii,ii);
% end
 y1=Result1(1,1:800);

graph1 =plot(x,y1);
set(graph1,'LineWidth',1.5);

hold on

% y2=Result2(point,1:800);
%  graph2 =plot(x,y2);
%  set(graph2,'LineWidth',1.5);
% 
% hold on
% x=0.2;
% y=0:10E-08:10E-03; %How much is long
%plot(x, y, 'LineWidth', 2) % but is not large enough
xlabel('time (s)')
ylabel('displacement (in)')
h =legend('pore pressure','total vertical stress');
set(h,'FontSize',15);
set(gca,'FontSize',15)
grid on
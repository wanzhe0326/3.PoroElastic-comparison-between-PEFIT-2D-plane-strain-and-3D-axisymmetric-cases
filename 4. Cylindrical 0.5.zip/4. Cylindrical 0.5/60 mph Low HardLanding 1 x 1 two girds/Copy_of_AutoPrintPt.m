for ii=1:1:800 
    
      file=[num2str(ii),'-Noncrack.mat'];
      load(file)
    
for jj=0:1:399
    
             result1111(jj+1,ii+jj)=sigma_zz(400-jj,7);
             result2222(jj+1,ii+jj)=sigma_zz(400-jj,12);
             result3333(jj+1,ii+jj)=sigma_zz(400-jj,19);    
    
             result4444(jj+1,ii+jj)=  p(400-jj,7);
             result5555(jj+1,ii+jj)=  p(400-jj,12);
             result6666(jj+1,ii+jj)=  p(400-jj,19);             
             
             result7777(jj+1,ii+jj)=sigma_zz(400-jj,1);  
end

 for jj=400:1:799

             result1111(jj+1,ii+jj)=sigma_zz(jj-399,7);
             result2222(jj+1,ii+jj)=sigma_zz(jj-399,12);
             result3333(jj+1,ii+jj)=sigma_zz(jj-399,19);    
    
             result4444(jj+1,ii+jj)=  p(jj-399,7);
             result5555(jj+1,ii+jj)=  p(jj-399,12);
             result6666(jj+1,ii+jj)=  p(jj-399,19);   
     
             result7777(jj+1,ii+jj)=sigma_zz(jj-399,1);       
 end
 
end


result1111(1,:)=result11111(1,:);
result2222(1,:)=result22222(1,:);
result3333(1,:)=result33333(1,:);
result4444(1,:)=result44444(1,:);
result5555(1,:)=result55555(1,:);
result6666(1,:)=result66666(1,:);


 Result1=sum(result1111);
 Result2=sum(result2222);
 Result3=sum(result3333);
 Result4=sum(result4444);
 Result5=sum(result5555);
 Result6=sum(result6666);
 Result7=sum(result7777);
 
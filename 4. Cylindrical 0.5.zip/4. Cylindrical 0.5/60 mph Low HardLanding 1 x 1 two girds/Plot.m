i=2;

switch(i)
    
    case 1
        
 x=-199:1:200;

 
% plot(x,Result1(1,1:400),'r','LineWidth',1.5);
% hold on
% % plot(x,result111,'k','LineWidth',1.5);
% xlabel('Distance from wheel load to point (in)') 
% ylabel('Vertical stress (psi)') 
% legend({'3D','2D ML'})
% 
% plot(x,Result2(1,1:400),'r','LineWidth',1.5);
% hold on
% % plot(x,result222,'k','LineWidth',1.5);
% xlabel('Distance from wheel load to point (in)') 
% ylabel('Vertical stress (psi)') 
% legend({'3D','2D ML'})
% 
% plot(x,Result3(1,1:400),'r','LineWidth',1.5);
% hold on
% % plot(x,result333,'k','LineWidth',1.5);
% xlabel('Distance from wheel load to point (in)') 
% ylabel('Vertical stress (psi)') 
% legend({'3D','2D ML'})

    case 2
        
 x=-199:1:200;

% plot(x,Result4(1,1:400),'r','LineWidth',1.5);
% % hold on
% %  plot(x,result4,'k','LineWidth',1.5);
% % plot(x,result44,'g','LineWidth',1.5);
% % plot(x,result444,'b','LineWidth',1.5);
% % plot(x,result444444,'m','LineWidth',1.5);
% % 
% xlabel('Distance from wheel load to point (in)') 
% ylabel('Pore pressure (psi)') 
% % legend({'3D','2D 1in','2D 2in','2D 3in'})


% plot(x,Result5(1,1:400),'r','LineWidth',1.5);
% hold on
% % plot(x,result5,'k','LineWidth',1.5);
% % plot(x,result55,'g','LineWidth',1.5);
% % plot(x,result555,'b','LineWidth',1.5);
% % plot(x,result555555,'m','LineWidth',1.5);
% % 
% xlabel('Distance from wheel load to point (in)') 
% ylabel('Pore pressure (psi)') 
% % legend({'3D','2D 1in','2D 2in','2D 3in'})



% 
plot(x,Result6(1,1:400),'r','LineWidth',1.5);
hold on
% plot(x,result6,'k','LineWidth',1.5);
% plot(x,result66,'g','LineWidth',1.5);
% plot(x,result666,'b','LineWidth',1.5);

% plot(x,result666666,'m','LineWidth',1.5);
% 
xlabel('Distance from wheel load to point (in)') 
ylabel('Pore pressure (psi)') 
% legend({'3D','2D 1in','2D 2in','2D 3in'})

%     case 3
%  x=-199:1:200;
% A = result333(1,1:400)- Result3(1,1:400);
% plot(x,A,'r','LineWidth',1.5);
% xlabel('Distance (in)') 
% ylabel('Difference vertical stress (psi)') 
%  legend({'(Moving Point) - (Moving Load)'})
% 
% 
%     case 4
%  x=-199:1:200;
% B=result666-Result6(1,1:400);
% plot(x,B,'k','LineWidth',1.5);
% xlabel('Distance (in)') 
% ylabel('Difference pore pressure (psi)') 
%  legend({'(Moving Point) - (Moving Load)'})
% 
end


ax = gca;
ax.FontSize = 15;


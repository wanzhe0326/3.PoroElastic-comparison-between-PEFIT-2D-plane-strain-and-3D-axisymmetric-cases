function [ NCsigma_rr,NCsigma_zz,NCsigma_rz,NCsigma_tt,NCp]=AbsorbingBoundary(NCsigma_rr,NCsigma_zz,NCsigma_rz,NCsigma_tt,NCp,boundary,BABS,nr,nz)
%----------------------------------------------------------------------------------------------------------------------------------------------------------------
% for   i=1:1:boundary
%     
%    j=1:1:ny;
%   
% NCsigma_xx(i,j)=NCsigma_xx(i,j)-(boundary-i)*BABS*NCsigma_xx(i,j);       
% 
% NCsigma_y(i,j)=NCsigma_y(i,j)-(boundary-i)*BABS*NCsigma_y(i,j);      
% 
%             
% NCp(i,j)=NCp(i,j)-(boundary-i)*BABS*NCp(i,j);  
% 
%       j=1:1:(ny+1);  
%       
% NCsigma_xy(i,j)=NCsigma_xy(i,j)-(boundary-i)*BABS*NCsigma_xy(i,j); 
%    
% end

%Right Side


for   i=(nr-boundary+1):1:nr
    
      j=1:1:nz;
  
NCsigma_rr(i,j)=NCsigma_rr(i,j)-(i-(nr-boundary+1))*BABS*NCsigma_rr(i,j);       

NCsigma_zz(i,j)=NCsigma_zz(i,j)-(i-(nr-boundary+1))*BABS*NCsigma_zz(i,j);      
         
NCp(i,j)=NCp(i,j)-(i-(nr-boundary+1))*BABS*NCp(i,j);  

      j=1:1:(nz+1);  
      
NCsigma_rz(i,j)=NCsigma_rz(i,j)-(i-(nr-boundary+1))*BABS*NCsigma_rz(i,j); 
   
end    



function [ Coeff_21,Coeff_22,Coeff_23,Coeff_24,Coeff_25,Coeff_26,Coeff_27,Coeff_28,Coeff_41,Coeff_42,Coeff_43,Coeff_44,Coeff_45,Coeff_46,Coeff_47,Coeff_48,Coeff_49,Coeff_410,Coeff_411,Coeff_412,Coeff_413,Coeff_414]=InputPoroElastic(M,b,alpha,f,m,poisson,rho,rhof,E,dz,dt,dr)
%----------------------------------------------------------------------------------------------------------------------------------------------------------------


lambda = E*poisson/(1+poisson)/(1-2*poisson);
miu=E/2/(1+poisson);

        Coeff_2 = dt * 1/( rho*m - rhof^2 );
        Coeff_21 = Coeff_2 * m/dr;
        Coeff_22 = Coeff_2 * m/dz;
        Coeff_23 = Coeff_2 * rhof /dz;
        Coeff_24 = Coeff_2 * rhof *b;
        Coeff_25 = Coeff_2 * rho /dz;
        Coeff_26 = Coeff_2 * rho *b;
        Coeff_27 = Coeff_2 * rhof /dr;
        Coeff_28 = Coeff_2 * rho /dr;

        Coeff_41 =  dt * M /dr ;
        Coeff_42 =  dt * M /dz ;
        Coeff_43 = Coeff_41 * alpha  ;
        Coeff_44 = Coeff_42 * alpha  ;
        Coeff_45 = (lambda + alpha^2 *M + 2 * miu) * dt /dr  ;
        Coeff_46 = (lambda + alpha^2 *M + 2 * miu) * dt /dz  ;
        Coeff_47=( lambda + alpha^2 *M )*dt/dr;
        Coeff_48=( lambda + alpha^2 *M )*dt/dz;
        Coeff_49= miu *dt/dz;
        Coeff_410=miu *dt/dr;
        Coeff_411=rhof/m;
        Coeff_412=(dz/m)*b*rhof;
        Coeff_413=rhof/rho*dz/dr;
        Coeff_414=rhof/rho;


% Picture Generator

% PP=zero(50,14); % 50-width; 14-depth;


% for i=1:1:300
% 
% PP=zeros(30,14);
% 
% if i<=30
%     
%    for j=1:i
%        
%     PP(1,i-j+1) = Result1(1,j);
%     
%    end
%    
% else
%     
%    for j=1:30
%        
%     PP(1,30-j+1) = Result1(1,j+(i-30));
%     
%    end
%    
% end
% 
%  file=[num2str(i),'-PorePressure.mat'];   
%  save(file)   
% end
   
for i=1:1:600

PP=zeros(600,14);

    
   for j=1:i
       
    PP(1,i-j+1) = Result1(1,j+200);
    
   end

 file=[num2str(i),'-PorePressure.mat'];   
 save(file)   
end


% Result2
% Result3
% Result4
% Result5
% Result6
% Result7
% Result8
% Result9
% Result10
% Result11
% Result12
% Result13
% Result14










%       if tt/INTERVAL==fix(tt/INTERVAL)
%              
%       file=[num2str(tt/INTERVAL),'-PorePressure.mat'];
%      
%       save(file)
%       
%       end
function [ NCv11,NCv12,av11new1,av12new1,av12new2,av12new3,av12new4,av11new2,av11new3]=VelocityElastic(R,j1up,j1down,j2up,j2down,nr,NCv11,NCv12,NCsigma_rr,NCsigma_zz,NCsigma_rz,NCsigma_tt,Coeff_11,Coeff_12,FourthOrder,tt,av11new1,av12new1,av12new2,av12new3,av12new4,av11new2,av11new3)
%----------------------------------------------------------------------------------------------------------------------------------------------------------------

j=j1up:j1down ;          
i=1; 

DNCsigma_rz1 = NCsigma_rz(i+1,j+1)- NCsigma_rz(i,j+1);
DNCsigma_zz = NCsigma_zz(i,j+1)-NCsigma_zz(i,j);

switch(tt)
    
    case 1
        
    a=1;
    b=-j1up+j1down+1;
    
        av12new1=zeros(a,b);
end
        av12old1 = av12new1;
        
av12new1=( Coeff_11 * ( DNCsigma_rz1 ) + Coeff_12*( DNCsigma_zz )+Coeff_11*( 1./(R(i,j)).*NCsigma_rz(i+1,j+1) ) );

          NCv12(i,j) = NCv12(i,j) + 3/2*av12new1 -1/2 * av12old1 ;

% j=1:1:(TLT/dz) ;         
i=nr;   

DNCsigma_rz1 = NCsigma_rz(i+1,j+1)- NCsigma_rz(i,j+1);
DNCsigma_zz = NCsigma_zz(i,j+1)-NCsigma_zz(i,j);

switch(tt)
      
    case 1
        
     a=1;
     b=-j1up+j1down+1;
     
         av12new2=zeros(a,b);

end
         av12old2 = av12new2;
         

av12new2=( Coeff_11 * ( DNCsigma_rz1 ) + Coeff_12*( DNCsigma_zz ) + Coeff_11 * 1/2 * ( 1./(R(i,j)).*NCsigma_rz(i+1,j+1)+1./((R(i,j)-1)).*NCsigma_rz(i,j+1) ) );

          NCv12(i,j) = NCv12(i,j) + 3/2 * av12new2 -1/2 * av12old2 ;

          
          
j=j1up:-j1up+j1down:j1down ;                    
i=2:1:nr-1;   

DNCsigma_rz1 = NCsigma_rz(i+1,j+1)- NCsigma_rz(i,j+1);
DNCsigma_zz = NCsigma_zz(i,j+1)-NCsigma_zz(i,j);

switch(tt)
      
    case 1
    a=nr-2;
    b=2;
    
         av12new3=zeros(a,b);

end
         av12old3 = av12new3;
         

av12new3=( Coeff_11 * ( DNCsigma_rz1 ) + Coeff_12*( DNCsigma_zz ) + Coeff_11 * 1/2 * ( 1./(R(i,j)).*NCsigma_rz(i+1,j+1)+1./((R(i,j)-1)).*NCsigma_rz(i,j+1) ) );

          NCv12(i,j) = NCv12(i,j) + 3/2 * av12new3 -1/2 * av12old3 ;
          
          
%44444444444444444444444          
          
    j=(j1up+1):1:(j1down-1);             
    i=2:1:nr-1;   

switch(FourthOrder)
    case 1
DNCsigma_rz1 = ( 27*( NCsigma_rz(i+1,j+1)- NCsigma_rz(i,j+1) ) - ( NCsigma_rz(i+2,j+1)- NCsigma_rz(i-1,j+1) ) ) / 24;
DNCsigma_zz = ( 27* ( NCsigma_zz(i,j+1)-NCsigma_zz(i,j) ) -( NCsigma_zz(i,j+2)-NCsigma_zz(i,j-1) ) )/24;        
    case 0
DNCsigma_rz1 = NCsigma_rz(i+1,j+1)- NCsigma_rz(i,j+1);
DNCsigma_zz = NCsigma_zz(i,j+1)-NCsigma_zz(i,j);
end


switch(tt)
      
    case 1
        
     a=nr-2;
     b=-(j1up+1)+(j1down-1)+1;
     
         av12new4=zeros(a,b);

end
         av12old4 = av12new4;
         

        av12new4=( Coeff_11 * ( DNCsigma_rz1 ) + Coeff_12*( DNCsigma_zz ) + Coeff_11 * 1/2 * ( 1./(R(i,j)).*NCsigma_rz(i+1,j+1)+1./((R(i,j)-1)).*NCsigma_rz(i,j+1) ) );

          NCv12(i,j) = NCv12(i,j) + 3/2 * av12new4 -1/2 * av12old4 ;
          
                    
    j=j2up:j2down ;            
    i=2:(nr-2):nr ;   

DNCsigma_rr = NCsigma_rr(i,j)-NCsigma_rr(i-1,j);
DNCsigma_rz2 = NCsigma_rz(i,j+1) - NCsigma_rz(i,j);

switch(tt)
      
    case 1
     a=2;
     b=-j2up+j2down+1;
     
         av11new1=zeros(a,b);
end
         av11old1 = av11new1;
         
         av11new1=( Coeff_11* (DNCsigma_rr) + Coeff_12* ( DNCsigma_rz2 )+ Coeff_11*1/2*( 1./(R(i,j)-1/2).*(NCsigma_rr(i,j)-NCsigma_tt(i,j))+ 1./(R(i,j)-3/2).*(NCsigma_rr(i-1,j)-NCsigma_tt(i-1,j)) ) );
     
          NCv11(i,j)=NCv11(i,j) + 3/2 * av11new1 - 1/2* av11old1;

          
j=j2up:(-j2up+j2down):j2down ;            
i=3:1:(nr-1) ;   

DNCsigma_rr = NCsigma_rr(i,j)-NCsigma_rr(i-1,j);
DNCsigma_rz2 = NCsigma_rz(i,j+1) - NCsigma_rz(i,j);

switch(tt)
      
    case 1
        
    a=nr-3;
    b=2;
       
         av11new2=zeros(a,b);
end
         av11old2 = av11new2;
         
         av11new2=( Coeff_11* (DNCsigma_rr) + Coeff_12* ( DNCsigma_rz2 )+ Coeff_11*1/2*( 1./(R(i,j)-1/2).*(NCsigma_rr(i,j)-NCsigma_tt(i,j))+ 1./(R(i,j)-3/2).*(NCsigma_rr(i-1,j)-NCsigma_tt(i-1,j)) ) );
     
          NCv11(i,j)=NCv11(i,j) + 3/2 * av11new2 - 1/2* av11old2;

% 44444444444444
 
j=(j2up+1):1:(j2down-1);            
i=3:1:(nr-1) ;   

switch(FourthOrder)
    
    case 1
DNCsigma_rr =( 27* ( NCsigma_rr(i,j)-NCsigma_rr(i-1,j) ) - ( NCsigma_rr(i+1,j)-NCsigma_rr(i-2,j) ))/24;
DNCsigma_rz2 =( 27* ( NCsigma_rz(i,j+1) - NCsigma_rz(i,j) ) - ( NCsigma_rz(i,j+2) - NCsigma_rz(i,j-1) ))/24;
    case 0
DNCsigma_rr = NCsigma_rr(i,j)-NCsigma_rr(i-1,j);
DNCsigma_rz2 = NCsigma_rz(i,j+1) - NCsigma_rz(i,j);
end

switch(tt)
      
    case 1
        
    a=nr-3;
    b=-(j2up+1)+(j2down-1)+1;
    
         av11new3=zeros(a,b);
end
         av11old3 = av11new3;
         
         av11new3=( Coeff_11* (DNCsigma_rr) + Coeff_12* ( DNCsigma_rz2 )+ Coeff_11*1/2*( 1./(R(i,j)-1/2).*(NCsigma_rr(i,j)-NCsigma_tt(i,j))+ 1./(R(i,j)-3/2).*(NCsigma_rr(i-1,j)-NCsigma_tt(i-1,j)) ) );
     
          NCv11(i,j)=NCv11(i,j) + 3/2 * av11new3 - 1/2* av11old3;       
          
for ii=201:1:1000 
    
      file=[num2str(ii),'-Noncrack.mat'];
      load(file)
    
for jj=0:1:399
    
             result11111(jj+1,ii+jj-200)=sigma_zz(400-jj,7);
             result22222(jj+1,ii+jj-200)=sigma_zz(400-jj,12);
             result33333(jj+1,ii+jj-200)=sigma_zz(400-jj,19);    
    
             result44444(jj+1,ii+jj-200)=  p(400-jj,7);
             result55555(jj+1,ii+jj-200)=  p(400-jj,12);
             result66666(jj+1,ii+jj-200)=  p(400-jj,19);             
             

end

 for jj=400:1:799

             result11111(jj+1,ii+jj-200)=sigma_zz(jj-399,7);
             result22222(jj+1,ii+jj-200)=sigma_zz(jj-399,12);
             result33333(jj+1,ii+jj-200)=sigma_zz(jj-399,19);    
    
             result44444(jj+1,ii+jj-200)=  p(jj-399,7);
             result55555(jj+1,ii+jj-200)=  p(jj-399,12);
             result66666(jj+1,ii+jj-200)=  p(jj-399,19);   
     
 end

end
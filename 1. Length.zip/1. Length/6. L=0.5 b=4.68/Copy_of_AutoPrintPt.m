


% result1=zeros(1,800); % 501 is 500 number 1 zero initial value
% result2=zeros(1,800);
% result3=zeros(1,800); % 501 is 500 number 1 zero initial value
% result4=zeros(1,800);
% result5=zeros(1,800); % 501 is 500 number 1 zero initial value
% result6=zeros(1,800);
% result7=zeros(1,800);
% result8=zeros(1,800);

% res=zeros(1,500);
% 6m equal to 
jj=200;
for ii=201:1:1000
              
      file=[num2str(ii),'-Noncrack.mat'];
      
      load(file)

     
      result1(1,ii-jj)=sigma_yy(1039,7);
      result2(1,ii-jj)=sigma_yy(1039,12);
      result3(1,ii-jj)=sigma_yy(1039,19);
      result4(1,ii-jj)=p(1039,7);
      result5(1,ii-jj)=p(1039,12);
      result6(1,ii-jj)=p(1039,19);
      result7(1,ii-jj)=sigma_yy(1039,1);

%       result111(1,ii-jj)=sigma_yy(541,5);
%       result222(1,ii-jj)=sigma_yy(541,7);
%       result333(1,ii-jj)=sigma_yy(541,10);
%       result444(1,ii-jj)=p(541,5);
%       result555(1,ii-jj)=p(541,7);
%       result666(1,ii-jj)=p(541,10);
%       result777(1,ii-jj)=sigma_yy(441,1);

end

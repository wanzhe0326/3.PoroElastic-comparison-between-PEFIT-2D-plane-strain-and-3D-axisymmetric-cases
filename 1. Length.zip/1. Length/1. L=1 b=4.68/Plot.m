i=4;

switch(i)
    
    case 1
 x=-199:1:200;
plot(x,Result3(1,1:400),'r','LineWidth',1.5);
hold on
plot(x,result333,'k','LineWidth',1.5);
xlabel('Distance (in)') 
ylabel('Vertical stress (psi)') 
legend({'Moving Point','Moving Load'})


    case 2
x=-199:1:200;
plot(x,Result6(1,1:400),'r','LineWidth',1.5);
hold on
plot(x,result666,'k','LineWidth',1.5);
xlabel('Distance (in)') 
ylabel('Pore pressure (psi)') 
legend({'Moving Point','Moving Load'})


    case 3
 x=-199:1:200;
A =abs( result333(1,1:400)- Result3(1,1:400));
plot(x,A,'r','LineWidth',1.5);
xlabel('Distance (in)') 
ylabel('Difference vertical stress (psi)') 
 legend({'abs(MP - ML)'})


    case 4
 x=-199:1:200;
B=abs(result666-Result6(1,1:400));
plot(x,B,'k','LineWidth',1.5);
xlabel('Distance (in)') 
ylabel('Difference pore pressure (psi)') 
 legend({'abs(MP - ML)'})

end


ax = gca;
ax.FontSize = 15;


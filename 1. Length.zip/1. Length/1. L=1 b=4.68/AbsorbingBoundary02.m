function [ NCsigma_xx,NCsigma_yy,NCsigma_xy,NCp]=AbsorbingBoundary02(NCsigma_xx,NCsigma_yy,NCsigma_xy,NCp,boundary,BABS,nx,ny)
%----------------------------------------------------------------------------------------------------------------------------------------------------------------
 for   i=1:1:boundary
%     
    j=1:1:ny;
   
 NCsigma_xx(i,j)=NCsigma_xx(i,j)-(boundary-i)*BABS*NCsigma_xx(i,j);       
 
 NCsigma_yy(i,j)=NCsigma_yy(i,j)-(boundary-i)*BABS*NCsigma_yy(i,j);      
            
 NCp(i,j)=NCp(i,j)-(boundary-i)*BABS*NCp(i,j);  
 
% 
       j=1:1:(ny+1);  
%       
 NCsigma_xy(i,j)=NCsigma_xy(i,j)-(boundary-i)*BABS*NCsigma_xy(i,j); 
%    
 end

 
%Right Side


for   i=(nx-boundary+1):1:nx
    
      j=1:1:ny;
  
NCsigma_xx(i,j)=NCsigma_xx(i,j)-(i-(nx-boundary+1))*BABS*NCsigma_xx(i,j);       

NCsigma_yy(i,j)=NCsigma_yy(i,j)-(i-(nx-boundary+1))*BABS*NCsigma_yy(i,j);      
         
NCp(i,j)=NCp(i,j)-(i-(nx-boundary+1))*BABS*NCp(i,j);  


      j=1:1:(ny+1);  
      
NCsigma_xy(i,j)=NCsigma_xy(i,j)-(i-(nx-boundary+1))*BABS*NCsigma_xy(i,j); 
   
end    


%Bottom Side

% 
% for   j=(ny+1-boundary+1):1:ny+1
%     
%       i=1:1:nx+1;
%   
% NCsigma_xx(i,j)=NCsigma_xx(i,j)-(j-(ny-boundary+1))*BABS*NCsigma_xx(i,j);       
% 
% NCsigma_yy(i,j)=NCsigma_yy(i,j)-(j-(ny-boundary+1))*BABS*NCsigma_yy(i,j);      
%          
% NCp(i,j)=NCp(i,j)-(j-(ny-boundary+1))*BABS*NCp(i,j);        
%       
% NCsigma_xy(i,j)=NCsigma_xy(i,j)-(j-(ny-boundary+1))*BABS*NCsigma_xy(i,j); 
%    
% 
% 
% end  


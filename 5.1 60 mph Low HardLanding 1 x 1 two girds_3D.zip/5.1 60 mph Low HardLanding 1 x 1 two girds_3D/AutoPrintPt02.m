for ii=1:1:800 
    
      file=[num2str(ii),'-Noncrack.mat'];
      load(file)
    
for jj=0:1:399
             
%             result1(jj+1,ii+jj)=NCv21(400-jj,7);
            result1(jj+1,ii+jj)=NCv21(400-jj,8);
            result2(jj+1,ii+jj)=NCv21(400-jj,9);
            result3(jj+1,ii+jj)=NCv21(400-jj,10);
            result4(jj+1,ii+jj)=NCv21(400-jj,11);
            result5(jj+1,ii+jj)=NCv21(400-jj,12);
            result6(jj+1,ii+jj)=NCv21(400-jj,13);
            result7(jj+1,ii+jj)=NCv21(400-jj,14);           
            result8(jj+1,ii+jj)=NCv21(400-jj,15);
            result9(jj+1,ii+jj)=NCv21(400-jj,16);
            result10(jj+1,ii+jj)=NCv21(400-jj,17);
            result11(jj+1,ii+jj)=NCv21(400-jj,18);
            result12(jj+1,ii+jj)=NCv21(400-jj,19);

          
%            result2(jj+1,ii+jj)=NCeff_sigma_zz(400-jj,8);
%            result3(jj+1,ii+jj)=NCp(400-jj,7);
%            result4(jj+1,ii+jj)=NCu12(400-jj,1);
%            result5(jj+1,ii+jj)=NCu11(400-jj,2);
%            result6(jj+1,ii+jj)=NCu12(400-jj,6);
%            result7(jj+1,ii+jj)=NCu11(400-jj,7);
%            result8(jj+1,ii+jj)=NCp(400-jj,13);
%            result9(jj+1,ii+jj)=NCp(400-jj,19);
end

for jj=400:1:799
             

          result1(jj+1,ii+jj)=-NCv21(jj-399,8); 
          result2(jj+1,ii+jj)=-NCv21(jj-399,9);
          result3(jj+1,ii+jj)=-NCv21(jj-399,10);          
          result4(jj+1,ii+jj)=-NCv21(jj-399,11);
          result5(jj+1,ii+jj)=-NCv21(jj-399,12); 
          result6(jj+1,ii+jj)=-NCv21(jj-399,13);
          result7(jj+1,ii+jj)=-NCv21(jj-399,14);           
          result8(jj+1,ii+jj)=-NCv21(jj-399,15);
          result9(jj+1,ii+jj)=-NCv21(jj-399,16); 
          result10(jj+1,ii+jj)=-NCv21(jj-399,17);
          result11(jj+1,ii+jj)=-NCv21(jj-399,18);          
          result12(jj+1,ii+jj)=-NCv21(jj-399,19);


          
          
%           result2(jj+1,ii+jj)=NCeff_sigma_zz(jj-399,8);
%           result3(jj+1,ii+jj)=NCp(jj-399,7);
%           result4(jj+1,ii+jj)=NCu12(jj-399,1);
%           result5(jj+1,ii+jj)=NCu11(jj-399,2);
%           result6(jj+1,ii+jj)=NCu12(jj-399,6);
%           result7(jj+1,ii+jj)=NCu11(jj-399,7);
%           result8(jj+1,ii+jj)=NCp(jj-399,13);
%           result9(jj+1,ii+jj)=NCp(jj-399,19);
end
end
 Result1=sum(result1);
 Result2=sum(result2);
 Result3=sum(result3);
 Result4=sum(result4);
 Result5=sum(result5);
 Result6=sum(result6);
 Result7=sum(result7);
 Result8=sum(result8);
 Result9=sum(result9);
 Result10=sum(result10);
 Result11=sum(result11);
 Result12=sum(result12);
%  Result13=sum(result13);
%  Result14=sum(result14);

% Low60=sum(result3);
% Result4=sum(result4);
% Result5=sum(result5);
% Result6=sum(result6);
% Result7=sum(result7);
% Low60M=sum(result8);
% Low60B=sum(result9);
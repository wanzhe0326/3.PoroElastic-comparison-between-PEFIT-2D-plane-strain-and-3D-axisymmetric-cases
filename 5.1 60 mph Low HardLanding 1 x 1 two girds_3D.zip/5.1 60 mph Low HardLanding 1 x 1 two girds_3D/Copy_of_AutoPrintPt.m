for ii=1:1:400 
    
      file=[num2str(ii),'-Noncrack.mat'];
      load(file)
    
for jj=0:1:199
    
             result1111(jj+1,ii+jj)=sigma_zz(200-jj,5);
             result2222(jj+1,ii+jj)=sigma_zz(200-jj,7);
             result3333(jj+1,ii+jj)=sigma_zz(200-jj,10);    
    
             result4444(jj+1,ii+jj)=  p(200-jj,5);
             result5555(jj+1,ii+jj)=  p(200-jj,7);
             result6666(jj+1,ii+jj)=  p(200-jj,10);             
             
             result7(jj+1,ii+jj)=sigma_zz(200-jj,1);  
end

 for jj=200:1:399

             result1111(jj+1,ii+jj)=sigma_zz(jj-199,5);
             result2222(jj+1,ii+jj)=sigma_zz(jj-199,7);
             result3333(jj+1,ii+jj)=sigma_zz(jj-199,10);    
    
             result4444(jj+1,ii+jj)=  p(jj-199,5);
             result5555(jj+1,ii+jj)=  p(jj-199,7);
             result6666(jj+1,ii+jj)=  p(jj-199,10);   
     
             result7777(jj+1,ii+jj)=sigma_zz(jj-199,1);       
 end
 
end


result1111(1,:)=result11111(1,:);
result2222(1,:)=result22222(1,:);
result3333(1,:)=result33333(1,:);
result4444(1,:)=result44444(1,:);
result5555(1,:)=result55555(1,:);
result6666(1,:)=result66666(1,:);


 Result1=sum(result1111);
 Result2=sum(result2222);
 Result3=sum(result3333);
 Result4=sum(result4444);
 Result5=sum(result5555);
 Result6=sum(result6666);
 Result7=sum(result7);
 
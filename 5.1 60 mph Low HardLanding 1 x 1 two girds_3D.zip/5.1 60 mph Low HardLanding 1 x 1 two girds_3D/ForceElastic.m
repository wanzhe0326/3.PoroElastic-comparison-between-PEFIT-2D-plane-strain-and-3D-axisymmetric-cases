function [ NCsigma_rr,NCsigma_zz,NCsigma_rz,NCsigma_tt,NCp,aNCsigma_rrnew1,aNCsigma_rrnew2,aNCsigma_zznew1,aNCsigma_zznew2,aNCsigma_ttnew1,aNCsigma_ttnew2,aNCsigma_rznew1,aNCsigma_rrnew3,aNCsigma_rrnew4,aNCsigma_zznew3,aNCsigma_zznew4,aNCsigma_ttnew3,aNCsigma_ttnew4,aNCsigma_rznew2,aNCsigma_rznew3]=ForceElastic(R,j1up,j1down,j2up,j2down,nr,NCsigma_rr,NCsigma_zz,NCsigma_tt,NCsigma_rz,NCp,Coeff_32,Coeff_34,Coeff_36,Coeff_38,Coeff_39,Coeff_310,NCv11,NCv12,FourthOrder,tt,aNCsigma_rrnew1,aNCsigma_rrnew2,aNCsigma_zznew1,aNCsigma_zznew2,aNCsigma_ttnew1,aNCsigma_ttnew2,aNCsigma_rznew1,aNCsigma_rrnew3,aNCsigma_rrnew4,aNCsigma_zznew3,aNCsigma_zznew4,aNCsigma_ttnew3,aNCsigma_ttnew4,aNCsigma_rznew2,aNCsigma_rznew3)
%----------------------------------------------------------------------------------------------------------------------------------------------------------------

 j=j1up:1:j1down  ;         
 i=1 ; 
 
DNCv111 = NCv11(i+1,j) - NCv11(i,j);
DNCv121 = NCv12(i,j) - NCv12(i,j-1);

 Average1=1./R(i,j).*NCv11(i+1,j);
 
 
switch(tt)
    
    case 1
        
    a=1;
    b=-j1up+j1down+1;
    
        aNCsigma_rrnew1=zeros(a,b);
        aNCsigma_zznew1=zeros(a,b);
        aNCsigma_ttnew1=zeros(a,b);

end

       aNCsigma_rrold1 = aNCsigma_rrnew1;
       aNCsigma_zzold1 = aNCsigma_zznew1;
       aNCsigma_ttold1 = aNCsigma_ttnew1;

 
    aNCsigma_rrnew1 =( Coeff_32 * ( DNCv111 )  +   Coeff_36 *( DNCv121 )+Coeff_38*( Average1 ) );
    aNCsigma_zznew1 =( Coeff_34 * ( DNCv121 ) +  Coeff_38 *( DNCv111 +(Average1) ) );
    aNCsigma_ttnew1 =( Coeff_32 *( Average1 )  +   Coeff_36 *( DNCv121 )+ Coeff_38*( DNCv111 )  );
 
        NCsigma_rr(i,j) = NCsigma_rr(i,j) + 3/2 * aNCsigma_rrnew1 -1/2 * aNCsigma_rrold1 ;                                                                                
        
        NCsigma_zz(i,j) = NCsigma_zz(i,j) + 3/2 * aNCsigma_zznew1 -1/2 * aNCsigma_zzold1 ;
    
        NCsigma_tt(i,j) = NCsigma_tt(i,j) + 3/2 * aNCsigma_ttnew1 -1/2 * aNCsigma_ttold1;                                       

 j=j1up:1:j1down  ;         
 i=nr  ; 
 
DNCv111 = NCv11(i+1,j) - NCv11(i,j);
DNCv121 = NCv12(i,j) - NCv12(i,j-1);

 Average1=1./R(i,j).*NCv11(i+1,j) +1./(R(i,j)-1).* NCv11(i,j);
 
 switch(tt)
      
    case 1
        
        a=1;
        b=-j1up+j1down+1;
        
        aNCsigma_rrnew2=zeros(a,b);
        aNCsigma_zznew2=zeros(a,b);
        aNCsigma_ttnew2=zeros(a,b);

 end
       aNCsigma_rrold2 = aNCsigma_rrnew2;
       aNCsigma_zzold2 = aNCsigma_zznew2;
       aNCsigma_ttold2 = aNCsigma_ttnew2;

 
 aNCsigma_rrnew2=( Coeff_32 * ( DNCv111 )  +   Coeff_36 *( DNCv121 )+Coeff_38*1/2*( Average1) );
 aNCsigma_zznew2=( Coeff_34 * ( DNCv121 ) +  Coeff_38 *( DNCv111 +1/2*(Average1) ) );
 aNCsigma_ttnew2=( Coeff_32 *1/2* ( Average1 )  +   Coeff_36 *( DNCv121 )+ Coeff_38*( DNCv111 ) );
     
        NCsigma_rr(i,j) = NCsigma_rr(i,j) + 3/2 *  aNCsigma_rrnew2 -1/2 *  aNCsigma_rrold2 ;                                                                                
                
        NCsigma_zz(i,j) = NCsigma_zz(i,j) + 3/2 *  aNCsigma_zznew2 -1/2 * aNCsigma_zzold2 ;
    
        NCsigma_tt(i,j) = NCsigma_tt(i,j) + 3/2 * aNCsigma_ttnew2 -1/2 * aNCsigma_ttold2;                                       
 
        
    j=j1up:(-j1up+j1down):j1down  ;      
    i=2:1:(nr-1)  ; 
 
DNCv111 = NCv11(i+1,j) - NCv11(i,j);
DNCv121 = NCv12(i,j) - NCv12(i,j-1);

 Average1=1./R(i,j).*NCv11(i+1,j) +1./(R(i,j)-1).* NCv11(i,j);
 
 switch(tt)
      
    case 1
        
        a=nr-2;
        b=2;
        
        aNCsigma_rrnew3=zeros(a,b);
        aNCsigma_zznew3=zeros(a,b);
        aNCsigma_ttnew3=zeros(a,b);

 end
       aNCsigma_rrold3 = aNCsigma_rrnew3;
       aNCsigma_zzold3 = aNCsigma_zznew3;
       aNCsigma_ttold3 = aNCsigma_ttnew3;

 
 aNCsigma_rrnew3=( Coeff_32 * ( DNCv111 )  +   Coeff_36 *( DNCv121 )+Coeff_38*1/2*( Average1) );
 aNCsigma_zznew3=( Coeff_34 * ( DNCv121 ) +  Coeff_38 *( DNCv111 +1/2*(Average1) ) );
 aNCsigma_ttnew3=( Coeff_32 *1/2* ( Average1 )  +   Coeff_36 *( DNCv121 )+ Coeff_38*( DNCv111 ) );
     
        NCsigma_rr(i,j) = NCsigma_rr(i,j) + 3/2 *  aNCsigma_rrnew3 -1/2 *  aNCsigma_rrold3 ;                                                                                
                
        NCsigma_zz(i,j) = NCsigma_zz(i,j) + 3/2 *  aNCsigma_zznew3 -1/2 * aNCsigma_zzold3 ;
    
        NCsigma_tt(i,j) = NCsigma_tt(i,j) + 3/2 * aNCsigma_ttnew3 -1/2 * aNCsigma_ttold3;                                       
        
%4444444444444444444444444444444444444444444444444444444444    

    j=(j1up+1):1:(j1down-1);      
    i=2:1:(nr-1)  ; 
    
switch(FourthOrder)
    
    case 1 
        
DNCv111 =( 27* ( NCv11(i+1,j) - NCv11(i,j)) - (( NCv11(i+2,j) - NCv11(i-1,j)) ))/24 ;
DNCv121 = ( 27* ( NCv12(i,j) - NCv12(i,j-1) ) - ( ( NCv12(i,j+1) - NCv12(i,j-2) ) ))/ 24 ;

    case 0
        
DNCv111 = NCv11(i+1,j) - NCv11(i,j);
DNCv121 = NCv12(i,j) - NCv12(i,j-1);

end

 Average1=1./R(i,j).*NCv11(i+1,j) +1./(R(i,j)-1).* NCv11(i,j);
 
 switch(tt)
      
    case 1
        
        a=nr-2;
        b=-(j1up+1)+(j1down-1)+1;
        
        aNCsigma_rrnew4=zeros(a,b);
        aNCsigma_zznew4=zeros(a,b);
        aNCsigma_ttnew4=zeros(a,b);

 end
       aNCsigma_rrold4 = aNCsigma_rrnew4;
       aNCsigma_zzold4 = aNCsigma_zznew4;
       aNCsigma_ttold4 = aNCsigma_ttnew4;

 
 aNCsigma_rrnew4=( Coeff_32 * ( DNCv111 )  +   Coeff_36 *( DNCv121 )+Coeff_38*1/2*( Average1) );
 aNCsigma_zznew4=( Coeff_34 * ( DNCv121 ) +  Coeff_38 *( DNCv111 +1/2*(Average1) ) );
 aNCsigma_ttnew4=( Coeff_32 *1/2* ( Average1 )  +   Coeff_36 *( DNCv121 )+ Coeff_38*( DNCv111 ) );
     
        NCsigma_rr(i,j) = NCsigma_rr(i,j) + 3/2 *  aNCsigma_rrnew4 -1/2 *  aNCsigma_rrold4 ;                                                                                
                
        NCsigma_zz(i,j) = NCsigma_zz(i,j) + 3/2 *  aNCsigma_zznew4 -1/2 * aNCsigma_zzold4 ;
    
        NCsigma_tt(i,j) = NCsigma_tt(i,j) + 3/2 * aNCsigma_ttnew4 -1/2 * aNCsigma_ttold4;                                       
             
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
    
 j=j2up:1:j2down ; 
 i=2:(nr-2):nr;
 
 DNCv112 = NCv11(i,j) - NCv11(i,j-1);
 DNCv122 = NCv12(i,j-1)-NCv12(i-1,j-1);      
 
switch(tt)
      
    case 1
     a=2;
     b=-j2up+j2down+1;
     
        aNCsigma_rznew1=zeros(a,b);
        
end 
        aNCsigma_rzold1=aNCsigma_rznew1;
        
        aNCsigma_rznew1=( Coeff_310 *( DNCv112 )  + Coeff_39 * ( DNCv122 ) );
 
        NCsigma_rz(i,j) = NCsigma_rz(i,j) +  3/2 * aNCsigma_rznew1 - 1/2 * aNCsigma_rzold1 ;

        
 j=j2up:(-j2up+j2down):j2down ; 
 i=3:(nr-1);
 
 DNCv112 = NCv11(i,j) - NCv11(i,j-1);
 DNCv122 = NCv12(i,j-1)-NCv12(i-1,j-1);      
 
switch(tt)
      
    case 1
     a=nr-3;
     b=2;
        aNCsigma_rznew2=zeros(a,b);
        
end 
        aNCsigma_rzold2=aNCsigma_rznew2;
        
        aNCsigma_rznew2=( Coeff_310 *( DNCv112 )  + Coeff_39 * ( DNCv122 ) );
 
        NCsigma_rz(i,j) = NCsigma_rz(i,j) +  3/2 * aNCsigma_rznew2 - 1/2 * aNCsigma_rzold2 ;
        
%4444444444444444444444444444444444444444444444444444444444        

 j=(j2up+1):1:(j2down-1) ; 
 i=3:(nr-1);
 
 switch(FourthOrder)
    
    case 1 
        
 DNCv112 = ( 27* ( NCv11(i,j) - NCv11(i,j-1) ) - ( ( NCv11(i,j+1) - NCv11(i,j-2) ) ) ) /24 ;
 DNCv122 = ( 27 * ( NCv12(i,j-1)-NCv12(i-1,j-1) ) - ( NCv12(i+1,j-1)-NCv12(i-2,j-1) ) )/24; 
 
    case 0 
        
 DNCv112 = NCv11(i,j) - NCv11(i,j-1);
 DNCv122 = NCv12(i,j-1)-NCv12(i-1,j-1);  
 
 end
 
switch(tt)
      
    case 1
     a=nr-3;
     b=-((j2up+1))+((j2down-1))+1;
     
        aNCsigma_rznew3=zeros(a,b);
        
end 
        aNCsigma_rzold3=aNCsigma_rznew3;
        
        aNCsigma_rznew3=( Coeff_310 *( DNCv112 )  + Coeff_39 * ( DNCv122 ) );
 
        NCsigma_rz(i,j) = NCsigma_rz(i,j) +  3/2 * aNCsigma_rznew3 - 1/2 * aNCsigma_rzold3 ;

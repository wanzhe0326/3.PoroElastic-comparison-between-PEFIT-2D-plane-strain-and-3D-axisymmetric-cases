for ii=101:1:500 
    
      file=[num2str(ii),'-Noncrack.mat'];
      load(file)
    
for jj=0:1:199
    
             result11111(jj+1,ii+jj-100)=sigma_zz(200-jj,5);
             result22222(jj+1,ii+jj-100)=sigma_zz(200-jj,7);
             result33333(jj+1,ii+jj-100)=sigma_zz(200-jj,10);    
    
             result44444(jj+1,ii+jj-100)=  p(200-jj,5);
             result55555(jj+1,ii+jj-100)=  p(200-jj,7);
             result66666(jj+1,ii+jj-100)=  p(200-jj,10);             
             

end

 for jj=200:1:399

             result11111(jj+1,ii+jj-100)=sigma_zz(jj-199,5);
             result22222(jj+1,ii+jj-100)=sigma_zz(jj-199,7);
             result33333(jj+1,ii+jj-100)=sigma_zz(jj-199,10);    
    
             result44444(jj+1,ii+jj-100)=  p(jj-199,5);
             result55555(jj+1,ii+jj-100)=  p(jj-199,7);
             result66666(jj+1,ii+jj-100)=  p(jj-199,10);   
     
 end

end
function [ Coeff_11,Coeff_12,Coeff_32,Coeff_34,Coeff_36,Coeff_38,Coeff_39,Coeff_310 ]=InputElastic(poisson,rhos,E,dz,dt,dr)
%----------------------------------------------------------------------------------------------------------------------------------------------------------------


lambda = E*poisson/(1+poisson)/(1-2*poisson);
miu=E/2/(1+poisson);

Coeff_1 = dt * 1/ rhos;
Coeff_11=Coeff_1 / dr;
Coeff_12=Coeff_1 / dz;

Coeff_3 = dt*(lambda + 2 * miu) ;
Coeff_32= Coeff_3 / dr;
Coeff_34= Coeff_3 / dz;
Coeff_36= lambda * dt / dz ;
Coeff_38= lambda * dt / dr ;
Coeff_39= miu * dt / dr;
Coeff_310= miu * dt / dz;


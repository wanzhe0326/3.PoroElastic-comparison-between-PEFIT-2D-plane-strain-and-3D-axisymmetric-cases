
ii=800;

file=[num2str(ii),'-Noncrack.mat'];
      
load(file)

A=NCsigma_zz;
B=NCu12;
C=zeros(size(B));
for i=1:98
    
        C(:,i+1)=(B(:,i)-B(:,i+1))./(48.75-0.5*(i-1));
end

i=1:6;
    C1=L1E*C(:,i+1);
    A1=A(:,i+1);
    D1=(abs(abs(C1)-abs(A1))./abs(A1)).*100;